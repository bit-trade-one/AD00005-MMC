//	USB�p�h���R���g���[��
//		ver13	2010/07/31	USB�̃��C�u�������t�H���_�ɂ��ꂱ��
//		ver12	2010/07/27	���쐫���P(1�����Ȃ���3�ō����h���b�O�ړ�)
//		ver11	2010/07/26	20100710��Ή���
//		ver0.5A	2010/07/07	���쐫���P
//		ver0.5	2010/07/07	�z�C�[���Ή�
//		ver0.4	2010/07/07	miniPAD�̃}�E�X��
//		ver0.3	2010/05/25	Microchip�̃T���v���v���O���������ɁA�\�[�X�̐���

#ifndef USBMOUSE_C
#define USBMOUSE_C

#define	SW_UP		PORTCbits.RC4
#define SW_DOWN		PORTBbits.RB7
#define	SW_LEFT		PORTCbits.RC7
#define SW_RIGHT	PORTCbits.RC5
#define SW_BUTTON1	PORTBbits.RB6
#define SW_BUTTON2	PORTBbits.RB5
#define	SW_BUTTON3	PORTBbits.RB4

#define IGN_BUTTON_DF	10000
//�����𒲐߂���ƁA�}�E�X�̑��x��ς��鎖���o���܂��B
#define MOUSE_SPEED	1
#define TEMP_BUFFER_LIM_INIT	500
#define TEMP_BUFFER_LIM_DEC		10
#define TEMP_BUFFER_LIM_MIN		80
#define TEMP_BUFFER_LIM_MAXSP	30
#define TEMP_BUFFER_LIM_INTERVAL_INIT	100
#define TEMP_BUFFER_LIM3		3000
#define TEMP_BUFFER_LIM3_MAXSP	1000

#define MODE_DRAG_OFF	0
#define MODE_DRAG_ON	1

/** INCLUDES *******************************************************/
#include <adc.h>
#include "./USB/usb.h"
#include "HardwareProfile.h"
#include "./USB/usb_function_hid.h"

/** CONFIGURATION **************************************************/
#pragma config CPUDIV = NOCLKDIV
#pragma config USBDIV = OFF
#pragma config FOSC   = HS
#pragma config PLLEN  = ON
#pragma config FCMEN  = OFF
#pragma config IESO   = OFF
#pragma config PWRTEN = OFF
#pragma config BOREN  = OFF
#pragma config BORV   = 30
#pragma config WDTEN  = OFF
#pragma config WDTPS  = 32768
#pragma config MCLRE  = OFF
#pragma config HFOFST = OFF
#pragma config STVREN = ON
#pragma config LVP    = OFF
#pragma config XINST  = OFF
#pragma config BBSIZ  = OFF
#pragma config CP0    = OFF
#pragma config CP1    = OFF
#pragma config CPB    = OFF
#pragma config WRT0   = OFF
#pragma config WRT1   = OFF
#pragma config WRTB   = OFF
#pragma config WRTC   = OFF
#pragma config EBTR0  = OFF
#pragma config EBTR1  = OFF
#pragma config EBTRB  = OFF        

/** VARIABLES ******************************************************/
#pragma udata
char buffer[4];
int temp_buffer[4];
int temp_buffer_lim[4];
int temp_buffer_lim_interval = TEMP_BUFFER_LIM_INTERVAL_INIT;
unsigned int ign_button3 = 0;
char mode_drag = MODE_DRAG_OFF;
char lever_status = 0;
char pre_lever_status = 0;

USB_HANDLE lastTransmission;

/** PRIVATE PROTOTYPES *********************************************/
void Emulate_Mouse(void);
static void InitializeSystem(void);
void ProcessIO(void);
void UserInit(void);
void YourHighPriorityISRCode();
void YourLowPriorityISRCode();

/** VECTOR REMAPPING ***********************************************/
#define REMAPPED_RESET_VECTOR_ADDRESS			0x1000
#define REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x1008
#define REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x1018

extern void _startup (void);        // See c018i.c in your C18 compiler dir
#pragma code REMAPPED_RESET_VECTOR = REMAPPED_RESET_VECTOR_ADDRESS
void _reset (void)
{
    _asm goto _startup _endasm
}
#pragma code REMAPPED_HIGH_INTERRUPT_VECTOR = REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS
void Remapped_High_ISR (void)
{
     _asm goto YourHighPriorityISRCode _endasm
}
#pragma code REMAPPED_LOW_INTERRUPT_VECTOR = REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS
void Remapped_Low_ISR (void)
{
     _asm goto YourLowPriorityISRCode _endasm
}
	
#pragma code HIGH_INTERRUPT_VECTOR = 0x08
void High_ISR (void)
{
     _asm goto REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS _endasm
}
#pragma code LOW_INTERRUPT_VECTOR = 0x18
void Low_ISR (void)
{
     _asm goto REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS _endasm
}

#pragma code
	
	
	//These are your actual interrupt handling routines.
#pragma interrupt YourHighPriorityISRCode
void YourHighPriorityISRCode()
{
		//Check which interrupt flag caused the interrupt.
		//Service the interrupt
		//Clear the interrupt flag
		//Etc.
		
}	//This return will be a "retfie fast", since this is in a #pragma interrupt section 
#pragma interruptlow YourLowPriorityISRCode
void YourLowPriorityISRCode()
{
		//Check which interrupt flag caused the interrupt.
		//Service the interrupt
		//Clear the interrupt flag
		//Etc.
	
}	//This return will be a "retfie", since this is in a #pragma interruptlow section 





/** DECLARATIONS ***************************************************/
#pragma code

void main(void)
{
    InitializeSystem();

    while(1)
    {
        USBDeviceTasks(); // Interrupt or polling method.  If using polling, must call

        ProcessIO();        
    }//end while
}//end main


static void InitializeSystem(void)
{

    UserInit();

    USBDeviceInit();	//usb_device.c.  Initializes USB module SFRs and firmware
}//end InitializeSystem


void UserInit(void)
{
	TRISB = 0xF0;	//RB4,5,6,7�����
	TRISC = 0xB0;	//RC4,5,7�����

    ADCON1 |= 0x0F;                 // Default all pins to digital
	ANSEL = 0x00;
	ANSELH = 0x00;	//�S�ăf�W�^��

	INTCON2bits.RABPU = 0;	//�����v���A�b�v���g����悤�ɂ���
	WPUBbits.WPUB4 = 1;
	WPUBbits.WPUB5 = 1;
	WPUBbits.WPUB6 = 1;
	WPUBbits.WPUB7 = 1;

    buffer[0]=buffer[1]=buffer[2]=buffer[3]=0; //USB�o�b�t�@����ɂ���
	temp_buffer[0]=temp_buffer[1]=temp_buffer[2]=temp_buffer[3]= 0;
	temp_buffer_lim[0]=temp_buffer_lim[1]=temp_buffer_lim[2]=temp_buffer_lim[3]= TEMP_BUFFER_LIM_INIT;

    //initialize the variable holding the handle for the last
    // transmission
    lastTransmission = 0;
}//end UserInit


void ProcessIO(void)
{
    // User Application USB tasks
    if((USBDeviceState < CONFIGURED_STATE)||(USBSuspendControl==1)) return;

    //Call the function that emulates the mouse
    Emulate_Mouse();
    
}//end ProcessIO


void Emulate_Mouse(void)
{   
	char tmp;

//�{�^���̏���
//���N���b�N	�F	�uBUTTON1��������Ă��āABUTTON3��������Ă��Ȃ��v�������́uBUTTON1��������Ă��āA�h���b�O���[�h��ON�v
//�E�N���b�N	�F	BUTTON2��������Ă��āABUTTON3��������Ă��Ȃ�
//�z�C�[���{�^��	�F	BUTTON2��BUTTON3��������Ă���
	buffer[0] = ((!SW_BUTTON1 * SW_BUTTON3) | (!SW_BUTTON1 & (mode_drag == MODE_DRAG_ON))) + ((!SW_BUTTON2 * SW_BUTTON3) << 1) + ((!SW_BUTTON2 * !SW_BUTTON3) << 2);
//�}�E�X�ړ��̏���
//���E�ړ��̏���	�F	BUTTON1��BUTTON3�̗�����������Ă��Ȃ��A�Ⴕ���̓h���b�O���[�h��ON�̎��ɓ���
	temp_buffer[1] += (!SW_RIGHT * MOUSE_SPEED * (SW_BUTTON3 | SW_BUTTON1 | (mode_drag == MODE_DRAG_ON)));
	temp_buffer[1] -= (!SW_LEFT * MOUSE_SPEED * (SW_BUTTON3 | SW_BUTTON1 | (mode_drag == MODE_DRAG_ON)));
	temp_buffer[2] += (!SW_DOWN * MOUSE_SPEED * (SW_BUTTON3 | SW_BUTTON1 | (mode_drag == MODE_DRAG_ON)));
	temp_buffer[2] -= (!SW_UP * MOUSE_SPEED * (SW_BUTTON3 | SW_BUTTON1 | (mode_drag == MODE_DRAG_ON)));
//�z�C�[���̏���
//�z�C�[������		�F	BUTTON1��BUTTON3������������āA���h���b�O���[�h��OFF�̎��ɂ̓z�C�[���Ƃ��ē���
	temp_buffer[3] -= ((!SW_DOWN + !SW_RIGHT * 3) * (!SW_BUTTON3 & !SW_BUTTON1 & (mode_drag == MODE_DRAG_OFF)));
	temp_buffer[3] += ((!SW_UP   + !SW_LEFT  * 3) * (!SW_BUTTON3 & !SW_BUTTON1 & (mode_drag == MODE_DRAG_OFF)));

//temp_buffer��temp_buffer_lim�������܂��buffer�����Z�i���Z�j�����
	if(temp_buffer[1] > temp_buffer_lim[1])
	{
		temp_buffer[1]-=temp_buffer_lim[1];
		buffer[1]++;
	}
	if(temp_buffer[1] < (-1)*temp_buffer_lim[1])
	{
		temp_buffer[1]+=temp_buffer_lim[1];
		buffer[1]--;
	}
	if(temp_buffer[2] > temp_buffer_lim[2])
	{
		temp_buffer[2]-=temp_buffer_lim[2];
		buffer[2]++;
	}
	if(temp_buffer[2] < (-1)*temp_buffer_lim[2])
	{
		temp_buffer[2]+=temp_buffer_lim[2];
		buffer[2]--;
	}
	if(temp_buffer[3] > temp_buffer_lim[3])
	{
		temp_buffer[3]-=temp_buffer_lim[3];
		temp_buffer_lim[3] = TEMP_BUFFER_LIM3;
		buffer[3]++;
	}
	if(temp_buffer[3] < -temp_buffer_lim[3])
	{
		temp_buffer[3]+=temp_buffer_lim[3];
		temp_buffer_lim[3] = TEMP_BUFFER_LIM3;
		buffer[3]--;
	}
	//������������E�������Ă��Ȃ���
	//buffer[3]���N���A����i�z�C�[���̏�Ԃ����Z�b�g����j
	if(SW_UP & SW_DOWN & SW_RIGHT & SW_LEFT & (ign_button3 == 0))
	{
		ign_button3 == IGN_BUTTON_DF;
		temp_buffer_lim[3] = 100;
		buffer[3] = 0;
		temp_buffer[3] = 0;
	}
	if(ign_button3 != 0)
		ign_button3--;


//�i�K�I�ɑ������鏈��
	temp_buffer_lim_interval--;
	if(temp_buffer_lim_interval == 0)
	{
		temp_buffer_lim_interval = TEMP_BUFFER_LIM_INTERVAL_INIT;

		if(!SW_LEFT | !SW_RIGHT)
		{
			temp_buffer_lim[1] -= TEMP_BUFFER_LIM_DEC;
			if(temp_buffer_lim[1] < TEMP_BUFFER_LIM_MIN)
				temp_buffer_lim[1] = TEMP_BUFFER_LIM_MIN;
		}
		else
		{
			temp_buffer_lim[1] = TEMP_BUFFER_LIM_INIT;
		}

		if(!SW_UP | !SW_DOWN)
		{
			temp_buffer_lim[2] -= TEMP_BUFFER_LIM_DEC;
			if(temp_buffer_lim[2] < TEMP_BUFFER_LIM_MIN)
				temp_buffer_lim[2] = TEMP_BUFFER_LIM_MIN;
		}
		else
		{
			temp_buffer_lim[2] = TEMP_BUFFER_LIM_INIT;
		}
		
	}

	if(!SW_BUTTON3)
	{
		temp_buffer_lim[1] = TEMP_BUFFER_LIM_MAXSP;
		temp_buffer_lim[2] = TEMP_BUFFER_LIM_MAXSP;
	}

//�h���b�O���[�h�̏���
//�h���b�O���[�h�ւ́uBUTTON1��������Ă���ABUTTON3��������Ă��Ȃ���ԂŁv�A�����L�[�̂����ꂩ�������Ɠ���B
//BUTTON1���������ƁA�h���b�O���[�h�I��

	lever_status = !SW_UP | !SW_DOWN | !SW_LEFT | !SW_RIGHT;
	if((!SW_BUTTON1 & SW_BUTTON3) && (!pre_lever_status) && (lever_status != 0))
	{
		mode_drag = MODE_DRAG_ON;
	}
	pre_lever_status = lever_status;
	if(SW_BUTTON1)
	{
		mode_drag = MODE_DRAG_OFF;
	}

//USB�ł̑��M����
    if(HIDTxHandleBusy(lastTransmission) == 0)
    {
        //copy over the data to the HID buffer
        hid_report_in[0] = buffer[0];
        hid_report_in[1] = buffer[1];
        hid_report_in[2] = buffer[2];
        hid_report_in[3] = buffer[3];

		buffer[1] = 0;
		buffer[2] = 0;
		buffer[3] = 0;

        //Send the 4 byte packet over USB to the host.
        lastTransmission = HIDTxPacket(HID_EP, (BYTE*)hid_report_in, 0x04);
    }
}//end Emulate_Mouse



// ******************************************************************************************************
// ************** USB Callback Functions ****************************************************************
// ******************************************************************************************************
// The USB firmware stack will call the callback functions USBCBxxx() in response to certain USB related
// events.  For example, if the host PC is powering down, it will stop sending out Start of Frame (SOF)
// packets to your device.  In response to this, all USB devices are supposed to decrease their power
// consumption from the USB Vbus to <2.5mA each.  The USB module detects this condition (which according
// to the USB specifications is 3+ms of no bus activity/SOF packets) and then calls the USBCBSuspend()
// function.  You should modify these callback functions to take appropriate actions for each of these
// conditions.  For example, in the USBCBSuspend(), you may wish to add code that will decrease power
// consumption from Vbus to <2.5mA (such as by clock switching, turning off LEDs, putting the
// microcontroller to sleep, etc.).  Then, in the USBCBWakeFromSuspend() function, you may then wish to
// add code that undoes the power saving things done in the USBCBSuspend() function.

// The USBCBSendResume() function is special, in that the USB stack will not automatically call this
// function.  This function is meant to be called from the application firmware instead.  See the
// additional comments near the function.

/******************************************************************************
 * Function:        void USBCBSuspend(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Call back that is invoked when a USB suspend is detected
 *
 * Note:            None
 *****************************************************************************/
void USBCBSuspend(void)
{
	//Example power saving code.  Insert appropriate code here for the desired
	//application behavior.  If the microcontroller will be put to sleep, a
	//process similar to that shown below may be used:
	
	//ConfigureIOPinsForLowPower();
	//SaveStateOfAllInterruptEnableBits();
	//DisableAllInterruptEnableBits();
	//EnableOnlyTheInterruptsWhichWillBeUsedToWakeTheMicro();	//should enable at least USBActivityIF as a wake source
	//Sleep();
	//RestoreStateOfAllPreviouslySavedInterruptEnableBits();	//Preferrably, this should be done in the USBCBWakeFromSuspend() function instead.
	//RestoreIOPinsToNormal();									//Preferrably, this should be done in the USBCBWakeFromSuspend() function instead.

	//IMPORTANT NOTE: Do not clear the USBActivityIF (ACTVIF) bit here.  This bit is 
	//cleared inside the usb_device.c file.  Clearing USBActivityIF here will cause 
	//things to not work as intended.	
}


/******************************************************************************
 * Function:        void USBCBWakeFromSuspend(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The host may put USB peripheral devices in low power
 *					suspend mode (by "sending" 3+ms of idle).  Once in suspend
 *					mode, the host may wake the device back up by sending non-
 *					idle state signalling.
 *					
 *					This call back is invoked when a wakeup from USB suspend 
 *					is detected.
 *
 * Note:            None
 *****************************************************************************/
void USBCBWakeFromSuspend(void)
{
	// If clock switching or other power savings measures were taken when
	// executing the USBCBSuspend() function, now would be a good time to
	// switch back to normal full power run mode conditions.  The host allows
	// a few milliseconds of wakeup time, after which the device must be 
	// fully back to normal, and capable of receiving and processing USB
	// packets.  In order to do this, the USB module must receive proper
	// clocking (IE: 48MHz clock must be available to SIE for full speed USB
	// operation).
}

/********************************************************************
 * Function:        void USBCB_SOF_Handler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USB host sends out a SOF packet to full-speed
 *                  devices every 1 ms. This interrupt may be useful
 *                  for isochronous pipes. End designers should
 *                  implement callback routine as necessary.
 *
 * Note:            None
 *******************************************************************/
void USBCB_SOF_Handler(void)
{
    // No need to clear UIRbits.SOFIF to 0 here.
    // Callback caller is already doing that.
}

/*******************************************************************
 * Function:        void USBCBErrorHandler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The purpose of this callback is mainly for
 *                  debugging during development. Check UEIR to see
 *                  which error causes the interrupt.
 *
 * Note:            None
 *******************************************************************/
void USBCBErrorHandler(void)
{
    // No need to clear UEIR to 0 here.
    // Callback caller is already doing that.

	// Typically, user firmware does not need to do anything special
	// if a USB error occurs.  For example, if the host sends an OUT
	// packet to your device, but the packet gets corrupted (ex:
	// because of a bad connection, or the user unplugs the
	// USB cable during the transmission) this will typically set
	// one or more USB error interrupt flags.  Nothing specific
	// needs to be done however, since the SIE will automatically
	// send a "NAK" packet to the host.  In response to this, the
	// host will normally retry to send the packet again, and no
	// data loss occurs.  The system will typically recover
	// automatically, without the need for application firmware
	// intervention.
	
	// Nevertheless, this callback function is provided, such as
	// for debugging purposes.
}


/*******************************************************************
 * Function:        void USBCBCheckOtherReq(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        When SETUP packets arrive from the host, some
 * 					firmware must process the request and respond
 *					appropriately to fulfill the request.  Some of
 *					the SETUP packets will be for standard
 *					USB "chapter 9" (as in, fulfilling chapter 9 of
 *					the official USB specifications) requests, while
 *					others may be specific to the USB device class
 *					that is being implemented.  For example, a HID
 *					class device needs to be able to respond to
 *					"GET REPORT" type of requests.  This
 *					is not a standard USB chapter 9 request, and 
 *					therefore not handled by usb_device.c.  Instead
 *					this request should be handled by class specific 
 *					firmware, such as that contained in usb_function_hid.c.
 *
 * Note:            None
 *******************************************************************/
void USBCBCheckOtherReq(void)
{
    USBCheckHIDRequest();
}//end


/*******************************************************************
 * Function:        void USBCBStdSetDscHandler(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USBCBStdSetDscHandler() callback function is
 *					called when a SETUP, bRequest: SET_DESCRIPTOR request
 *					arrives.  Typically SET_DESCRIPTOR requests are
 *					not used in most applications, and it is
 *					optional to support this type of request.
 *
 * Note:            None
 *******************************************************************/
void USBCBStdSetDscHandler(void)
{
    // Must claim session ownership if supporting this request
}//end


/*******************************************************************
 * Function:        void USBCBInitEP(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is called when the device becomes
 *                  initialized, which occurs after the host sends a
 * 					SET_CONFIGURATION (wValue not = 0) request.  This 
 *					callback function should initialize the endpoints 
 *					for the device's usage according to the current 
 *					configuration.
 *
 * Note:            None
 *******************************************************************/
void USBCBInitEP(void)
{
    //enable the HID endpoint
    USBEnableEndpoint(HID_EP,USB_IN_ENABLED|USB_HANDSHAKE_ENABLED|USB_DISALLOW_SETUP);
}

/********************************************************************
 * Function:        void USBCBSendResume(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        The USB specifications allow some types of USB
 * 					peripheral devices to wake up a host PC (such
 *					as if it is in a low power suspend to RAM state).
 *					This can be a very useful feature in some
 *					USB applications, such as an Infrared remote
 *					control	receiver.  If a user presses the "power"
 *					button on a remote control, it is nice that the
 *					IR receiver can detect this signalling, and then
 *					send a USB "command" to the PC to wake up.
 *					
 *					The USBCBSendResume() "callback" function is used
 *					to send this special USB signalling which wakes 
 *					up the PC.  This function may be called by
 *					application firmware to wake up the PC.  This
 *					function should only be called when:
 *					
 *					1.  The USB driver used on the host PC supports
 *						the remote wakeup capability.
 *					2.  The USB configuration descriptor indicates
 *						the device is remote wakeup capable in the
 *						bmAttributes field.
 *					3.  The USB host PC is currently sleeping,
 *						and has previously sent your device a SET 
 *						FEATURE setup packet which "armed" the
 *						remote wakeup capability.   
 *
 *					This callback should send a RESUME signal that
 *                  has the period of 1-15ms.
 *
 * Note:            Interrupt vs. Polling
 *                  -Primary clock
 *                  -Secondary clock ***** MAKE NOTES ABOUT THIS *******
 *                   > Can switch to primary first by calling USBCBWakeFromSuspend()
 
 *                  The modifiable section in this routine should be changed
 *                  to meet the application needs. Current implementation
 *                  temporary blocks other functions from executing for a
 *                  period of 1-13 ms depending on the core frequency.
 *
 *                  According to USB 2.0 specification section 7.1.7.7,
 *                  "The remote wakeup device must hold the resume signaling
 *                  for at lest 1 ms but for no more than 15 ms."
 *                  The idea here is to use a delay counter loop, using a
 *                  common value that would work over a wide range of core
 *                  frequencies.
 *                  That value selected is 1800. See table below:
 *                  ==========================================================
 *                  Core Freq(MHz)      MIP         RESUME Signal Period (ms)
 *                  ==========================================================
 *                      48              12          1.05
 *                       4              1           12.6
 *                  ==========================================================
 *                  * These timing could be incorrect when using code
 *                    optimization or extended instruction mode,
 *                    or when having other interrupts enabled.
 *                    Make sure to verify using the MPLAB SIM's Stopwatch
 *                    and verify the actual signal on an oscilloscope.
 *******************************************************************/
void USBCBSendResume(void)
{
    static WORD delay_count;
    
    USBResumeControl = 1;                // Start RESUME signaling
    
    delay_count = 1800U;                // Set RESUME line for 1-13 ms
    do
    {
        delay_count--;
    }while(delay_count);
    USBResumeControl = 0;
}


/*******************************************************************
 * Function:        BOOL USER_USB_CALLBACK_EVENT_HANDLER(
 *                        USB_EVENT event, void *pdata, WORD size)
 *
 * PreCondition:    None
 *
 * Input:           USB_EVENT event - the type of event
 *                  void *pdata - pointer to the event data
 *                  WORD size - size of the event data
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is called from the USB stack to
 *                  notify a user application that a USB event
 *                  occured.  This callback is in interrupt context
 *                  when the USB_INTERRUPT option is selected.
 *
 * Note:            None
 *******************************************************************/
BOOL USER_USB_CALLBACK_EVENT_HANDLER(USB_EVENT event, void *pdata, WORD size)
{
    switch(event)
    {
        case EVENT_CONFIGURED: 
            USBCBInitEP();
            break;
        case EVENT_SET_DESCRIPTOR:
            USBCBStdSetDscHandler();
            break;
        case EVENT_EP0_REQUEST:
            USBCBCheckOtherReq();
            break;
        case EVENT_SOF:
            USBCB_SOF_Handler();
            break;
        case EVENT_SUSPEND:
            USBCBSuspend();
            break;
        case EVENT_RESUME:
            USBCBWakeFromSuspend();
            break;
        case EVENT_BUS_ERROR:
            USBCBErrorHandler();
            break;
        case EVENT_TRANSFER:
            Nop();
            break;
        default:
            break;
    }      
    return TRUE; 
}

/** EOF mouse.c *************************************************/
#endif

